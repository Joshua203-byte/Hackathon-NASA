# ALTARIS — Earth Trend Intelligence

Proyecto del equipo **ALTARIS** para el **NASA Space Apps Challenge 2026**.
Reto: **"Be An Earth System Trend Detective!"**

## Equipo

Camila, Elena, Joshua, David, Marro y Arlie.
Perfil: IA, programación, desarrollo de software, análisis de datos y electrónica. No somos especialistas en ciencias de la Tierra, climatología ni datos satelitales, por eso la solución prioriza el rigor y la honestidad científica.

## Idea en una línea

Una herramienta que toma datos reales de la NASA, detecta **tendencias de precipitación y variabilidad ligada a ENSO** en el Triángulo Norte (El Salvador, Guatemala y Honduras), y le dice al usuario **qué tan sólida es la evidencia** y **qué decisiones no debería tomar** con ella.

## Diferenciador: ALTARIS Evidence Verdict

En lugar de solo mostrar gráficas, ALTARIS emite un veredicto de confianza científica sobre cada tendencia. Principios:

- Sin predicciones.
- Sin afirmaciones causales no demostradas.
- Evaluación automática de robustez estadística.
- Indicador de completitud/calidad del dato (ej. "24/24 años válidos").

## Alcance

- Enfoque inicial: precipitación + ENSO.
- Región: El Salvador / Centroamérica (Triángulo Norte), con una propuesta que se sostenga en la competencia global.
- Implicaciones: comunidades, agricultura y energía.
- Tiempo disponible: ~24 horas. Video de entrega: 30 segundos.

## Contenido del repo

| Archivo | Qué contiene |
|---|---|
| [`docs/01-reto-y-contexto.md`](docs/01-reto-y-contexto.md) | Qué es el reto, restricciones y decisiones tomadas |
| [`docs/02-referentes-nasa.md`](docs/02-referentes-nasa.md) | Análisis de referentes (NASA POWER DAVe, AppEEARS) y qué robar para ALTARIS |
| [`docs/img/`](docs/img/) | Imágenes de apoyo |

> Nota: el documento base `ALTARIS_Documento_Ma...` que cita el análisis debe copiarse a `docs/` manualmente (no estaba disponible en esta sesión).
